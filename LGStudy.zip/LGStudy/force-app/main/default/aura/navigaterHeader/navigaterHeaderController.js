({
    doInit : function(component, event, helper) {
        // var url = $A.get("$Resource.LGImageSample/images/ico-search.svg");
        // component.set("v.inputSearchImg", url)
    }
})
