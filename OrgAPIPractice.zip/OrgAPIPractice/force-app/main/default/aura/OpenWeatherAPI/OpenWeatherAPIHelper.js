({
    getData : function(component, lat, lon) {
        console.log(lat, " : lat");
        console.log(lon, " : lon");

        var action = component.get('c.postOpenWeatherData');

        action.setParams({
            "endPointURL": `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=9b3848eeced0ec3282abafb62cd8bde6`
        });

        action.setCallback(this, function(res) {
            let resData = res.getReturnValue();
            let Date = [];
            console.log(resData.city, 'city');
            console.log(resData.list, 'list');

            component.set("v.cityName", resData.city.name);
            component.set("v.weatherList", resData.list);
            
            resData.list.forEach(weatherDate => {
                let month = weatherDate.dt_txt.split(" ")[0].split("-")[1];
                let day = weatherDate.dt_txt.split(" ")[0].split("-")[2];
                let hour = weatherDate.dt_txt.split(" ")[1].split(":")[0];

                Date.push({
                    "month": month,
                    "day": day,
                    "hour": hour
                });
            });
            component.set("v.weatherDate", Date)
        });

        $A.enqueueAction(action);
    }
})