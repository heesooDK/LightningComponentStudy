({
    // Your renderer method overrides go here
        render: function(component, helper) {
            let returnVal = component.superRender();
            let scrollSlider = component.find("weatherCmp").getElement();
    
            let isMove;
            let startX;
            let scrollLeft;
    
            console.log("event before")
    
            scrollSlider.addEventListener('mousedown', function(e) {
                console.log(scrollSlider)
                console.log("scroll Event Inside")
                console.log(scrollSlider.offsetLeft)
                isMove = true;
                startX = e.pageX - scrollSlider.offsetLeft;
                scrollLeft = scrollSlider.scrollLeft;
                console.log(startX)
                console.log(scrollLeft)
            })
        
            scrollSlider.addEventListener('mouseleave', function() {
                isMove = false;
            })
    
            scrollSlider.addEventListener('mouseup', function() {
                isMove = false;
            })
    
            scrollSlider.addEventListener('mousemove', function(e) {
                if(!isMove) return;
                e.preventDefault();
                const x = e.pageX - scrollSlider.offsetLeft;
                const walk = (x - startX) * 5; //scroll-fast
                scrollSlider.scrollLeft = scrollLeft - walk;
                // console.log(e.pageX, " :: pageX");
                // console.log(scrollSlider.offsetLeft, " :: scrollSlider");
                // console.log(e.offsetLeft, " :: offsetLeft")
                // console.log(x, " :: x");
                // console.log(x - startX, " :: minus");
                // console.log(walk, " :: walk");
            })
    
            return returnVal;
        }
    })
    