({
    handleCoordsEvent : function(cmp, event, helper) {
        let coords = event.getParam("coords");

        cmp.set("v.coords", coords);

        helper.getData(cmp, coords.lat, coords.lon);
    }
})