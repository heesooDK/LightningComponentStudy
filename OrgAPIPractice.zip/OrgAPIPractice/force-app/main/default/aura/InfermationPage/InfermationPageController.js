({
    doInit : function(cmp, event) {
        var latEvent = $A.get("e.c:childDataTransfer");
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                latEvent.setParams({
                    coords: {
                        lat: position.coords.latitude,
                        lon: position.coords.longitude
                    }
                });
                latEvent.fire();
            })
        }
    }
})
