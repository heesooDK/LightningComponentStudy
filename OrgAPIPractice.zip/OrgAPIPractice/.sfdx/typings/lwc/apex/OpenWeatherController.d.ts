declare module "@salesforce/apex/OpenWeatherController.postOpenWeatherData" {
  export default function postOpenWeatherData(param: {endPointURL: any}): Promise<any>;
}
